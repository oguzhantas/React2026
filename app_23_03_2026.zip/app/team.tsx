import { View, StyleSheet } from 'react-native';
import { useLocalSearchParams } from 'expo-router';

export default function TeamScreen() {
  const { name } = useLocalSearchParams();

  const getColors = () => {
    switch (name) {
      case 'fenerbahce':
        return ['yellow', 'navy'];
      case 'galatasaray':
        return ['yellow', 'red'];
      case 'besiktas':
        return ['black', 'white'];
      default:
        return ['white', 'white'];
    }
  };

  const [topColor, bottomColor] = getColors();

  return (
    <View style={styles.container}>
      <View style={[styles.half, { backgroundColor: topColor }]} />
      <View style={[styles.half, { backgroundColor: bottomColor }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  half: {
    flex: 1,
  },
});