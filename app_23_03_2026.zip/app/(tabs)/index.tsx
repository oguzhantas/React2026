import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { router } from 'expo-router';

export default function Home() {
  return (
    <View style={styles.container}>

      <TeamButton
        title="Fenerbahçe"
        image={require('../../assets/images/fenerbahce.png')}
        onPress={() => router.push('/team?name=fenerbahce')}
      />

      <TeamButton
        title="Galatasaray"
        image={require('../../assets/images/galatasaray.png')}
        onPress={() => router.push('/team?name=galatasaray')}
      />

      <TeamButton
        title="Beşiktaş"
        image={require('../../assets/images/besiktas.png')}
        onPress={() => router.push('/team?name=besiktas')}
      />

    </View>
  );
}

const TeamButton = ({ title, image, onPress }: any) => (
  <TouchableOpacity style={styles.button} onPress={onPress}>
    <Image source={image} style={styles.logo} />
    <Text style={styles.text}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-evenly',
    alignItems: 'center',
  },
  button: {
    width: 220,
    height: 120,
    backgroundColor: '#CCC',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
  },
  text: {
    marginTop: 8,
    fontSize: 16,
    fontWeight: '600',
    color:'#000',
  },
});