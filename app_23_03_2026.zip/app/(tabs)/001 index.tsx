
import { View, Text, StyleSheet } from 'react-native';


export default function BenimProje() {
  return (
      <View style={styles.Container}>
          <Text style={styles.FontTitle}> Merhaba React </Text>
      </View>
  );
}

const styles = StyleSheet.create({
  Container: {
    backgroundColor: 'yellow', //arka zemin rengi sarı
    flex:1, //ekranı %100 kaplasın
    alignItems: "center", //yatayda ortalama
    justifyContent: "center", //dikeyde ortalama
  },
  FontTitle:{
      fontSize: 20,
  }
  
});
