import { useState } from 'react';
//üçer üçer
function BenimButon3() {
  const [sayac, sayacArtir] = useState(0);

      function Tıkla3() {
        sayacArtir(sayac + 3);
      }

  return (
    <button onClick={Tıkla3}>
      {sayac} defa tıklandı
    </button>
  );
}


// beşer beşer
function BenimButon5() {
    const [sayac, sayacArtir] = useState(0);
  
        function Tıkla5() {
          sayacArtir(sayac + 5);
        }
  
    return (
      <button onClick={Tıkla5}>
        {sayac} defa tıklandı
      </button>
    );
  }

  export default function MyApp() {
    return (
      <div>
        <h1>Buton sayaç örneği</h1>
        <BenimButon3 />
        <BenimButon5 />
      </div>
    );
  }

  